"""One-off site update for sphragisai.com (Nov 2026). Idempotent.
1) copies payload/ over the repo  2) free session 45' -> 20'  3) old service names -> new
4) sitemap.xml and llms.txt entries for the service pages."""
import re, glob, shutil, pathlib

ROOT = pathlib.Path(".")
HERE = pathlib.Path(__file__).parent

# 1) payload
for p in (HERE / "payload").rglob("*"):
    if p.is_file():
        dst = ROOT / p.relative_to(HERE / "payload")
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, dst)

# 2) 45 -> 20 (free session only)
R45 = [
 (r'((?:δωρεάν|Δωρεάν) (?:session|συνεδρία(?: χαρτογράφησης)?|χαρτογράφηση)(?: των)? )45 λεπτών', r'\g<1>20 λεπτών'),
 (r'((?:συνεδρία|χαρτογράφηση|Συνεδρία|Χαρτογράφηση) )45′', r'\g<1>20′'),
 (r'(χαρτογράφησης )\(45′\)', r'\g<1>(20′)'),
 (r'45λεπτη', '20λεπτη'),
 (r'(?i)(free[^.<"]{0,30}?)45(-minute| minutes| min)', r'\g<1>20\g<2>'),
 (r'(session|Session|call) \(45 min\)', r'\g<1> (20 min)'),
 (r'(free |Free )45′', r'\g<1>20′'),
]
# 3) old names
SEC = re.compile(r'prompt|agent|threat|STRIDE|επικύρωσ|validation|βάσης γνώσης|knowledge-base|κρυφή|hidden instruction|injection|απομόνωση|isolation|ανίχνευση|anomaly|αρχιτεκτονική ασφάλειας', re.I)
NAME = {"rdy": "AI Readiness Check", "sec": "AI Security Assessment"}
def rename(t):
    def k(m): return "sec" if SEC.search(t[max(0, m.start() - 10):m.end() + 250]) else "rdy"
    t = re.sub(r'(Ο |ο |τον |Τον |του |Του )?(?:Έλεγχος|Έλεγχο|Ελέγχου) Θωράκισης',
               lambda m: {"Ο ": "Το ", "ο ": "το ", "τον ": "το ", "Τον ": "Το ", "του ": "του ", "Του ": "Του ", "": ""}[m.group(1) or ""] + NAME[k(m)], t)
    t = re.sub(r'(A |a |The |the )?Shielding (?:Audit|Review|Check)',
               lambda m: {"A ": "An ", "a ": "an ", "The ": "The ", "the ": "the ", "": ""}[m.group(1) or ""] + NAME[k(m)], t)
    return t.replace(' : συνέντευξη', ': συνέντευξη').replace(' : 45-minute', ': 45-minute')

files = [f for f in glob.glob("**/*.html", recursive=True)] + [".github/radar_build.py", ".github/radar-prompt.md"]
changed = 0
for f in files:
    p = pathlib.Path(f)
    if not p.exists(): continue
    o = p.read_text(encoding="utf-8"); t = o
    for a, b in R45: t = re.sub(a, b, t)
    if f.endswith(".html") and not f.startswith(("ypiresies/", "en/ypiresies/")): t = rename(t)
    if t != o: p.write_text(t, encoding="utf-8"); changed += 1
print("files changed:", changed)

# 4) sitemap + llms
SL = ["ai-readiness-check", "ai-security-assessment", "iso-42001", "iso-42001-27001", "ai-literacy", "annual-support"]
sm = pathlib.Path("sitemap.xml"); s = sm.read_text(encoding="utf-8")
if "/ypiresies/ai-readiness-check/" not in s:
    def blk(loc, el, en): return (f'<url><loc>{loc}</loc><xhtml:link rel="alternate" hreflang="el" href="{el}"/><xhtml:link rel="alternate" hreflang="en" href="{en}"/>'
                                  f'<xhtml:link rel="alternate" hreflang="x-default" href="{el}"/><lastmod>2026-11-13</lastmod><changefreq>monthly</changefreq><priority>0.8</priority></url>\n')
    add = "".join(blk(a, a, b) + blk(b, a, b) for a, b in ((f"https://sphragisai.com/ypiresies/{x}/", f"https://sphragisai.com/en/ypiresies/{x}/") for x in SL))
    s = s.replace("</urlset>", add + "</urlset>", 1); sm.write_text(s, encoding="utf-8")
ll = pathlib.Path("llms.txt"); l = ll.read_text(encoding="utf-8")
if "/ypiresies/ai-readiness-check/" not in l:
    names = {"ai-readiness-check": "AI Readiness Check: AI Act and ISO/IEC 42001 gap assessment", "ai-security-assessment": "AI Security Assessment: security testing of chatbots and AI agents",
             "iso-42001": "ISO/IEC 42001 AI management system implementation", "iso-42001-27001": "Integrated ISO/IEC 42001 & ISO/IEC 27001 system",
             "ai-literacy": "AI Literacy workshop (EU AI Act Article 4)", "annual-support": "Annual support for certified ISO/IEC 42001 / 27001 systems"}
    lines = "- [All services](https://sphragisai.com/en/ypiresies/) ([EL](https://sphragisai.com/ypiresies/))\n" + "".join(
        f"- [{names[x]}](https://sphragisai.com/en/ypiresies/{x}/) ([EL](https://sphragisai.com/ypiresies/{x}/))\n" for x in SL)
    l = l.replace("## Services\n\n", "## Services\n\n" + lines, 1); ll.write_text(l, encoding="utf-8")
print("done")
